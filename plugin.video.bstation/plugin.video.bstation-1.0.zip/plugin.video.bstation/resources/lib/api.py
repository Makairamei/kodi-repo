import requests
import json
from urllib.parse import quote

class BstationAPI:
    def __init__(self):
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
            "Referer": "https://www.bilibili.tv/",
            "Origin": "https://www.bilibili.tv"
        }
        self.cookies = {
            "SESSDATA": "a97adc61%2C1785509852%2Cdd028%2A210091",
            "bili_jct": "bca5203c3f1cda514530500a8ca0fc10",
            "DedeUserID": "1709563281",
            "buvid3": "ddbadfe4-0540-43ce-b22d-5644f59fded314589infoc",
            "bstar-web-lang": "en"
        }
        self.api_url = "https://api.bilibili.tv"
        self.biliintl_url = "https://api.biliintl.com"

    def get_timeline(self):
        url = f"{self.api_url}/intl/gateway/web/v2/ogv/timeline?s_locale=id_ID&platform=web"
        r = requests.get(url, headers=self.headers, cookies=self.cookies)
        data = r.json().get('data', {}).get('items', [])
        results = []
        for day in data:
            if not day.get('cards'): continue
            for card in day['cards']:
                results.append({
                    'title': card.get('title'),
                    'season_id': card.get('season_id'),
                    'cover': card.get('cover'),
                    'desc': card.get('index_show')
                })
        return results

    def search(self, query):
        url = f"{self.api_url}/intl/gateway/web/v2/search_result?keyword={quote(query)}&s_locale=id_ID&limit=20"
        r = requests.get(url, headers=self.headers, cookies=self.cookies)
        modules = r.json().get('data', {}).get('modules', [])
        results = []
        for module in modules:
            items = module.get('data', {}).get('items', [])
            for item in items:
                results.append({
                    'title': item.get('title'),
                    'season_id': item.get('season_id'),
                    'cover': item.get('cover')
                })
        return results

    def get_season_details(self, season_id):
        url = f"{self.api_url}/intl/gateway/v2/ogv/view/app/season?season_id={season_id}&platform=web&s_locale=id_ID"
        r = requests.get(url, headers=self.headers, cookies=self.cookies)
        res = r.json().get('result', {})
        
        episodes = []
        # Normal episodes
        if res.get('episodes'):
            episodes.extend(res['episodes'])
        # Section episodes
        if res.get('modules'):
            for m in res['modules']:
                 if m.get('data', {}).get('episodes'):
                     episodes.extend(m['data']['episodes'])
        
        # Deduplicate
        seen = set()
        unique_eps = []
        for ep in episodes:
            ep_id = str(ep.get('id'))
            if ep_id not in seen:
                seen.add(ep_id)
                unique_eps.append({
                    'id': ep_id,
                    'title': ep.get('title') or f"Episode {ep.get('index')}",
                    'index': ep.get('index_show'),
                    'cover': ep.get('cover')
                })
        
        return {
            'title': res.get('title'),
            'cover': res.get('cover'),
            'desc': res.get('evaluate'),
            'episodes': unique_eps
        }

    def get_play_data(self, ep_id):
        # Prefer BiliIntl API which works better
        url = f"{self.biliintl_url}/intl/gateway/web/playurl?ep_id={ep_id}&s_locale=id_ID&platform=android&qn=64"
        r = requests.get(url, headers=self.headers, cookies=self.cookies)
        data = r.json()
        
        playurl = data.get('data', {}).get('playurl', {})
        if not playurl:
            return None
            
        # Get DASH streams
        video_tracks = playurl.get('video', [])
        audio_tracks = playurl.get('audio_resource', [])
        
        if not video_tracks:
            return None
            
        # Check subtitles from Episode API
        sub_url = f"{self.api_url}/intl/gateway/v2/ogv/view/app/episode?ep_id={ep_id}&platform=web&s_locale=id_ID"
        try:
            r_sub = requests.get(sub_url, headers=self.headers, cookies=self.cookies)
            subs = r_sub.json().get('data', {}).get('subtitles', [])
        except:
            subs = []

        return {
            'videos': video_tracks,
            'audios': audio_tracks,
            'subs': subs,
            'duration': playurl.get('duration')
        }
