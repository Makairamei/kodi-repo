import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from urllib.parse import parse_qsl, quote_plus, unquote_plus
from resources.lib.api import BstationAPI

# Constants
_url = sys.argv[0]
_handle = int(sys.argv[1])
_addon = xbmcaddon.Addon()
_api = BstationAPI()

def get_url(**kwargs):
    return '{0}?{1}'.format(_url, '&'.join('{}={}'.format(k, quote_plus(str(v))) for k, v in kwargs.items()))

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    mode = params.get('mode')
    
    if mode is None:
        main_menu()
    elif mode == 'timeline':
        list_timeline()
    elif mode == 'search':
        search_menu()
    elif mode == 'do_search':
        do_search(params.get('query'))
    elif mode == 'episodes':
        list_episodes(params.get('id'))
    elif mode == 'play':
        play_video(params.get('id'), params.get('title'))

def main_menu():
    xbmcplugin.setPluginCategory(_handle, 'Bstation')
    
    # Timeline
    li = xbmcgui.ListItem(label='Jadwal Rilis (Home)')
    url = get_url(mode='timeline')
    xbmcplugin.addDirectoryItem(handle=_handle, url=url, listitem=li, isFolder=True)
    
    # Search
    li = xbmcgui.ListItem(label='Pencarian')
    url = get_url(mode='search')
    xbmcplugin.addDirectoryItem(handle=_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(_handle)

def list_timeline():
    xbmcplugin.setPluginCategory(_handle, 'Jadwal Rilis')
    xbmcplugin.setContent(_handle, 'videos')
    
    items = _api.get_timeline()
    for item in items:
        li = xbmcgui.ListItem(label=item['title'])
        li.setArt({'thumb': item['cover'], 'icon': item['cover'], 'fanart': item['cover']})
        li.setInfo('video', {'title': item['title'], 'plot': item['desc']})
        
        url = get_url(mode='episodes', id=item['season_id'])
        xbmcplugin.addDirectoryItem(handle=_handle, url=url, listitem=li, isFolder=True)
        
    xbmcplugin.endOfDirectory(_handle)

def search_menu():
    dialog = xbmcgui.Dialog()
    query = dialog.input('Search Anime', type=xbmcgui.INPUT_ALPHANUM)
    if query:
        do_search(query)

def do_search(query):
    xbmcplugin.setPluginCategory(_handle, f'Search: {query}')
    xbmcplugin.setContent(_handle, 'videos')
    
    items = _api.search(query)
    for item in items:
        li = xbmcgui.ListItem(label=item['title'])
        li.setArt({'thumb': item['cover'], 'icon': item['cover'], 'fanart': item['cover']})
        li.setInfo('video', {'title': item['title']})
        
        url = get_url(mode='episodes', id=item['season_id'])
        xbmcplugin.addDirectoryItem(handle=_handle, url=url, listitem=li, isFolder=True)
        
    xbmcplugin.endOfDirectory(_handle)

def list_episodes(season_id):
    details = _api.get_season_details(season_id)
    
    xbmcplugin.setPluginCategory(_handle, details.get('title', 'Unknown'))
    xbmcplugin.setContent(_handle, 'episodes')
    
    for ep in details['episodes']:
        title = f"{ep['index']} - {ep['title']}"
        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': ep['cover'], 'icon': ep['cover']})
        li.setInfo('video', {'title': title, 'plot': details.get('desc')})
        li.setProperty('IsPlayable', 'true')
        
        url = get_url(mode='play', id=ep['id'], title=ep['title'])
        xbmcplugin.addDirectoryItem(handle=_handle, url=url, listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(_handle)

def play_video(ep_id, title):
    data = _api.get_play_data(ep_id)
    if not data:
        xbmcgui.Dialog().notification('Error', 'No stream found', xbmcgui.NOTIFICATION_ERROR)
        return

    # Construct MPD (MPEG-DASH) Manifest manually
    # Because Bilibili gives separate audio/video URLs
    mpd_content = generate_mpd(data['videos'], data['audios'], data['duration'])
    
    # Save MPD to temp file or pass as string (if inputstream supports it, better use file)
    import os
    temp_dir = xbmc.translatePath("special://temp/")
    mpd_path = os.path.join(temp_dir, f"bstation_{ep_id}.mpd")
    
    with open(mpd_path, 'w') as f:
        f.write(mpd_content)
        
    # Setup Player
    li = xbmcgui.ListItem(label=title)
    li.setPath(mpd_path)
    
    # Inputstream Adaptive Properties
    li.setProperty('inputstream', 'inputstream.adaptive')
    li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
    li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha') # Just in case, though Bilibili mostly clear
    
    # Headers
    headers = "Referer=https://www.bilibili.tv/&User-Agent=Mozilla/5.0"
    li.setProperty('inputstream.adaptive.stream_headers', headers)
    
    # Subtitles
    for sub in data['subs']:
        li.addSubtitle(sub['url'])
        
    xbmcplugin.setResolvedUrl(_handle, True, listitem=li)

def generate_mpd(videos, audios, duration):
    # Determine max duration for MPD (usually in ISO 8601 duration format PT1H30M... but milliseconds works for some players)
    # Simple DASH MPD template
    mpd = '<?xml version="1.0" encoding="UTF-8"?>'
    mpd += '<MPD xmlns="urn:mpeg:dash:schema:mpd:2011" profiles="urn:mpeg:dash:profile:isoff-on-demand:2011" type="static" minBufferTime="PT1.5S" mediaPresentationDuration="PT{0}S">'.format(int(duration)/1000)
    mpd += '<Period>'
    
    # Video Adaptation Set
    mpd += '<AdaptationSet mimeType="video/mp4" contentType="video" subsegmentAlignment="true" subsegmentStartsWithSAP="1">'
    for vid in videos:
        res = vid.get('video_resource', {})
        if not res.get('url'): continue
        mpd += '<Representation id="{0}" bandwidth="{1}" width="{2}" height="{3}" codecs="{4}">'.format(
            res.get('quality'), res.get('bandwidth'), res.get('width'), res.get('height'), res.get('codecs', 'avc1.64001F'))
        mpd += '<BaseURL>{0}</BaseURL>'.format(res['url'].replace("&", "&amp;"))
        mpd += '</Representation>'
    mpd += '</AdaptationSet>'
    
    # Audio Adaptation Set
    if audios:
        mpd += '<AdaptationSet mimeType="audio/mp4" contentType="audio" subsegmentAlignment="true" subsegmentStartsWithSAP="1">'
        for aud in audios:
             if not aud.get('url'): continue
             mpd += '<Representation id="audio_{0}" bandwidth="{1}" codecs="{2}">'.format(
                 aud.get('quality'), aud.get('bandwidth'), aud.get('codecs', 'mp4a.40.2'))
             mpd += '<BaseURL>{0}</BaseURL>'.format(aud['url'].replace("&", "&amp;"))
             mpd += '</Representation>'
        mpd += '</AdaptationSet>'
        
    mpd += '</Period></MPD>'
    return mpd

if __name__ == '__main__':
    router(sys.argv[2][1:])
